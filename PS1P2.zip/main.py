#comment find average of exams and show name

LastName=input("Enter a LastName: ")
Exam1=int (input("Enter a number: "))
Exam2=int (input("Enter another number: "))

a= (Exam1 + Exam2) /2

print("Average is: ", a)
print(LastName)

