#comment find tip of meal

meal= float(input("enter amount of meal"))

tip=(meal * .15)

print("amount of tip: ", tip)