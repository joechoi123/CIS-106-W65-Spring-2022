#comment find Miles Per Gallon
gallons= int( input("enter amount of gallons: "))
miles= int( input("enter amount of miles: "))

mpg= (miles / gallons)

print("Miles per Gallon is: ", mpg)