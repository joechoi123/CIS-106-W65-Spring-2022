#

meal=float (input("enter amount of meal: "))

tip=(meal * .07)
total=(meal + tip)

print("amount of meal: ", meal)
print("amount of tip: ", tip)
print("total amount: ", total)